angular.module('myApp', [ 'ngTouch', 'onsen.directives']);

function HomeController($scope, $timeout){
    
    $timeout(function(){
        $scope.ons.screen.presentPage('page2.html');       
    }, 1000);
    
}